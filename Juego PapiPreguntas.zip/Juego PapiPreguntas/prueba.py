import sqlite3
from tkinter import *
from tkinter import messagebox as mb

class User:
    def __init__(self, username, password):
        self.username = username
        self.password = password

class Quiz:
    def __init__(self, master, current_user):
        self.master = master
        self.numeroPreguntas = 0
        self.display_title()
        self.opcionSeleccionada = IntVar()
        self.opciones = self.radio_buttons()
        self.buttons()
        self.correct = 0
        self.current_user = current_user

        self.connection = sqlite3.connect("sqlite.db")
        self.cursor = self.connection.cursor()

        self.cursor.execute("SELECT * FROM preguntas")
        self.questions_data = self.cursor.fetchall()
        self.data_size = len(self.questions_data)

        if self.data_size > 0:
            self.display_question()
            self.display_options()
        else:
            mb.showerror("Error", "No hay preguntas en la base de datos.")
            master.destroy()

    def display_result(self):
        wrong_count = self.data_size - self.correct
        correct = f"Correctas: {self.correct}"
        wrong = f"Erroneas (te falla): {wrong_count}"
        mb.showinfo("Papi resultados", f"\n{correct}\n{wrong}")
      #  if self.correct > 3 : 
      #  self.imagen = PhotoImage(file=f"happycat.png")
      #  self.label_imagen = Label(ventana, image=imagen)
      #  self.label_imagen.pack()
        

    def check_ans(self, numeroPreguntas):
        if self.opcionSeleccionada.get() == int(self.questions_data[numeroPreguntas][5]):
            return True

    def next_btn(self):
        if self.check_ans(self.numeroPreguntas):
            self.correct += 1

        self.numeroPreguntas += 1

        if self.numeroPreguntas == self.data_size:
            self.display_result()
            self.master.destroy()
        else:
            self.display_question()
            self.display_options()

    def buttons(self):
        next_button = Button(self.master, text="Siguiente papi pregunta", command=self.next_btn,
                             width=20, bg="#F0C6EB", fg="white", font=("ariel", 16, "bold"))
        next_button.place(x=250, y=380)

        quit_button = Button(self.master, text="Salir", command=self.master.destroy,
                             width=5, bg="#F0C6EB", fg="white", font=("ariel", 16, " bold"))
        quit_button.place(x=600, y=380)

    def display_options(self):
        val = 0
        self.opcionSeleccionada.set(0)

        for option in range(1, 5): 
            if val < len(self.opciones):
                self.opciones[val]['text'] = self.questions_data[self.numeroPreguntas][option]
                val += 1

    def display_question(self):
        numeroPreguntas = Label(self.master, text=self.questions_data[self.numeroPreguntas][0], width=60,
                     font=('ariel', 16, 'bold'), anchor='w')
        numeroPreguntas.place(x=70, y=100)

    def display_title(self):
        title = Label(self.master, text="Papi Preguntas",
                      width=70, bg="#F0C6EB", fg="white", font=("ariel", 20, "bold"))
        title.place(x=0, y=2)

    def radio_buttons(self):
        q_list = []
        y_pos = 150

        for _ in range(4):
            radio_btn = Radiobutton(self.master, text=" ", variable=self.opcionSeleccionada,
                                    value=len(q_list) + 1, font=("ariel", 14))
            q_list.append(radio_btn)
            radio_btn.place(x=100, y=y_pos)
            y_pos += 40

        return q_list

class RegistrationWindow:
    def __init__(self, master, auth_instance):
        self.master = master
        self.auth_instance = auth_instance
        self.create_registration_window()

    def create_registration_window(self):
        self.register_screen = Toplevel(self.master)
        self.register_screen.title("Registro")
        self.register_screen.geometry("400x300")

        Label(self.register_screen, text="Registro", font=("ariel", 16, "bold")).pack()

        self.username_label = Label(self.register_screen, text="Nombre de usuario:")
        self.username_label.pack()
        self.username_entry = Entry(self.register_screen)
        self.username_entry.pack()

        self.password_label = Label(self.register_screen, text="Contraseña:")
        self.password_label.pack()
        self.password_entry = Entry(self.register_screen, show="*")
        self.password_entry.pack()

        Button(self.register_screen, text="Registrarse", command=self.register_user).pack()

    def register_user(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        if self.auth_instance.register_user(username, password):
            self.register_screen.destroy()

class LoginWindow:
    def __init__(self, master, auth_instance):
        self.master = master
        self.auth_instance = auth_instance
        self.create_login_window()

    def create_login_window(self):
        self.login_screen = Toplevel(self.master)
        self.login_screen.title("Inicio de sesión")
        self.login_screen.geometry("400x300")

        Label(self.login_screen, text="Inicio de sesión", font=("ariel", 16, "bold")).pack()

        self.username_label = Label(self.login_screen, text="Nombre de usuario:")
        self.username_label.pack()
        self.username_entry = Entry(self.login_screen)
        self.username_entry.pack()

        self.password_label = Label(self.login_screen, text="Contraseña:")
        self.password_label.pack()
        self.password_entry = Entry(self.login_screen, show="*")
        self.password_entry.pack()

        Button(self.login_screen, text="Iniciar sesión", command=self.login_user).pack()

    def login_user(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        user = self.auth_instance.login_user(username, password)
        if user:
            self.login_screen.destroy()
            start_quiz(user)

def start_quiz(user):
    quiz_screen = Toplevel(ventana)
    quiz_screen.title("PAPI PREGUNTAS")
    quiz_screen.geometry("1000x450")

    quiz = Quiz(quiz_screen, user)

class Authentication:
    def __init__(self):
        self.users = []
        self.connection = sqlite3.connect("sqlite.db")
        self.cursor = self.connection.cursor()

    def register_user(self, username, password):
        self.cursor.execute("SELECT * FROM users WHERE username=?", (username,))
        existing_user = self.cursor.fetchone()

        if existing_user:
            mb.showerror("Error", "El usuario ya existe.")
            return False
        else:
            self.cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            self.connection.commit()
            mb.showinfo("Registro exitoso", "¡Registro completado!")
            return True

    def login_user(self, username, password):
        self.cursor.execute("SELECT * FROM users WHERE username=?", (username,))
        user_data = self.cursor.fetchone()
        if user_data:
            if password == user_data[2]:
                mb.showinfo("Inicio de sesión exitoso", "¡Bienvenid@!")
                return User(username, password)
            else:
                mb.showerror("Error de inicio de sesión", "Contraseña incorrecta.")
        else:
            mb.showerror("Error de inicio de sesión", "Usuario no encontrado. Por favor, regístrate.")
        return None

auth = Authentication()

ventana = Tk()
ventana.geometry("400x350")
ventana.title("Papi Preguntas")

register_button = Button(ventana, text="Registrarse", command=lambda: RegistrationWindow(ventana, auth))
register_button.pack(pady=20)

login_button = Button(ventana, text="Iniciar sesión", command=lambda: LoginWindow(ventana, auth))
login_button.pack(pady=20)

imagen = PhotoImage(file=f"elpapigato.png")
label_imagen = Label(ventana, image=imagen)
label_imagen.pack()


ventana.mainloop()
