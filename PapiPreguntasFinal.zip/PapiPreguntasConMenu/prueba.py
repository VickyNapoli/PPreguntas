import sqlite3
from tkinter import *
from tkinter import messagebox as mb
import random

class User:
    def __init__(self, username, password):
        self.username = username
        self.password = password

class Quiz:
    def __init__(self, master, current_user):
        self.master = master
        self.numeroPreguntas = 0
        self.mostrarTitulo()
        self.opcionSeleccionada = IntVar()
        self.opciones = self.radio_buttons()
        self.buttons()
        self.correctas = 0
        self.current_user = current_user

        self.connection = sqlite3.connect("sqlite.db")
        self.cursor = self.connection.cursor()

        self.cursor.execute("SELECT * FROM preguntas")
        self.questions_data = self.cursor.fetchall()
        self.data_size = len(self.questions_data)

        if self.data_size > 0:
            self.preguntasRandom = random.sample(self.questions_data, len(self.questions_data))
            self.mostrarPreguntas()
            self.mostrarOpciones(self.preguntasRandom[self.numeroPreguntas])
        else:
            mb.showerror("Error", "No hay preguntas en la base de datos.")
            master.destroy()

    def mostrarResultado(self):
        correctas = f"Puntaje: {self.correctas}"
        incorrectas = f"Le erraste amigo, te falla"
        
        
        mb.showinfo("Papi resultados", f"\n{correctas}\n{incorrectas}")


    def mostrarResultadoWin(self):
        correctas = f"Puntaje: {self.correctas}"
        text = f"Ganaste! Terminaste todas las preguntas"

        mb.showinfo("Papi resultados", f"\n{correctas}\n{text}")


    def checkearResultado(self):
        if self.opcionSeleccionada.get() == int(self.preguntasRandom[self.numeroPreguntas][5]):
            return True

    def botonSiguiente(self):
        if self.checkearResultado():
            self.correctas += 1
        else:
            self.mostrarResultado()
            self.master.destroy()
            return 

        self.numeroPreguntas += 1

        if self.numeroPreguntas == self.data_size:
            self.mostrarResultadoWin()
            self.master.destroy()
        else:
            self.mostrarPreguntas()

    def salir(self):
        self.master.destroy()
        if self.master.winfo_exists():     
            MainMenu(self.master, self.current_user)


    def buttons(self):
        siguienteBoton = Button(self.master, text="Siguiente papi pregunta", command=self.botonSiguiente,
                             width=20, bg="#ca61bf", fg="white", font=("arial", 16, "bold"))
        siguienteBoton.place(x=250, y=380)

        salirBoton = Button(self.master, text="Salir", command= self.salir,
                             width=8, bg="#ca61bf", fg="white", font=("arial", 16, " bold"))
        salirBoton.place(x=800, y=380)

    def mostrarPreguntas(self):
        question_data = self.preguntasRandom[self.numeroPreguntas]

        numeroPreguntas = Label(
            self.master,
            text=question_data[0],
            width=60,
            font=('arial', 16, 'bold'),
            bg="#fde9fb",
            anchor='w'
        )
        numeroPreguntas.place(x=70, y=100)

        self.mostrarOpciones(question_data)


    def mostrarOpciones(self, question_data):
        val = 0
        self.opcionSeleccionada.set(0)

        options = question_data[1:5]

        for option in options:
            if val < len(self.opciones):
                self.opciones[val]['text'] = option
                val += 1

    def mostrarTitulo(self):
        title = Label(self.master, text="Papi Preguntas",
                      width=70, bg="#ca61bf", fg="white", font=("arial", 20, "bold"))
        title.place(x=0, y=0)

    def radio_buttons(self):
        q_list = []

        for i in range(4):
            radio_btn = Radiobutton(
                self.master, text=" ", variable=self.opcionSeleccionada,
                value=len(q_list) + 1, font=("arial", 14), bg="#fde9fb"
            )
            q_list.append(radio_btn)
            radio_btn.place(x=100, y=150 + i * 40)

        return q_list


class RegisterPag:
    def __init__(self, master, auth_instance):
        self.master = master
        self.auth_instance = auth_instance
        self.crearRegister()

    def crearRegister(self):
        self.registerVentana = Toplevel(self.master)
        self.registerVentana.title("Registro")
        self.registerVentana.geometry("350x700")
        self.registerVentana.configure(bg='#fde9fb')



        self.imagenlogo = PhotoImage(file=f"logo.png").subsample(2, 2)
        self.label_imagenlogo = Label(self.registerVentana, image=imagenlogo)
        self.label_imagenlogo.pack()


        Label(self.registerVentana, text="Registro",  bg="#fde9fb", fg="#ca61bf", font=("arial", 20, "bold")).pack()

        self.username_label = Label(self.registerVentana, text="Nombre de usuario:",  bg="#fde9fb", font=("arial", 16))
        self.username_label.pack(pady=25)
        self.username_entry = Entry(self.registerVentana, width="30")
        self.username_entry.pack()

        self.password_label = Label(self.registerVentana, text="Contraseña:",  bg="#fde9fb", font=("arial", 16))
        self.password_label.pack(pady=15)
        self.password_entry = Entry(self.registerVentana, show="*", width="30")
        self.password_entry.pack()

        Button(self.registerVentana, text="Registrarse",  bg="#ca61bf", fg="white", font=("arial", 12, 'bold'), command=self.registrarUser).pack(pady=35)

    def registrarUser(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        if self.auth_instance.registrarUser(username, password):
            self.registerVentana.destroy()

class LoginPag:
    def __init__(self, master, auth_instance):
        self.master = master
        self.auth_instance = auth_instance
        self.create_login_window()

    def create_login_window(self):
        self.loginVentana = Toplevel(self.master)
        self.loginVentana.title("Inicio de sesión")
        self.loginVentana.geometry("350x700")
        self.loginVentana.configure(bg='#fde9fb')
        
        self.imagenlogo = PhotoImage(file=f"logo.png").subsample(2, 2)
        self.label_imagenlogo = Label(self.loginVentana, image=imagenlogo)
        self.label_imagenlogo.pack()

        Label(self.loginVentana, text="Inicio de sesión",  bg="#fde9fb", fg="#ca61bf", font=("arial", 20, "bold")).pack()

        self.username_label = Label(self.loginVentana, text="Nombre de usuario:",  bg="#fde9fb", font=("arial", 16))
        self.username_label.pack(pady=25)
        self.username_entry = Entry(self.loginVentana, width="30")
        self.username_entry.pack()

        self.password_label = Label(self.loginVentana, text="Contraseña:",  bg="#fde9fb", font=("arial", 16))
        self.password_label.pack(pady=15)
        self.password_entry = Entry(self.loginVentana, show="*", width="30")
        self.password_entry.pack()

        Button(self.loginVentana, text="Iniciar sesión", bg="#ca61bf", fg="white", font=("arial", 12, 'bold'), command=self.loginUser).pack(pady=35)

    def loginUser(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        user = self.auth_instance.loginUser(username, password)
        if user:
            self.loginVentana.destroy()           
            self.loginVentana.destroy()
            MainMenu(self.master, user)

class MainMenu:
    def __init__(self, master, current_user):
        self.master = master
        self.current_user = current_user
        self.crearMenu()

    def crearMenu(self):
        self.menuVentana = Toplevel(self.master)
        self.menuVentana.title("Menú Principal")
        self.menuVentana.geometry("400x500")
        self.menuVentana.resizable(False, False)
        self.menuVentana.configure(bg='#fde9fb')


        self.imagenlogo = PhotoImage(file=f"logo.png").subsample(6, 6)
        self.label_imagenlogo = Label(self.menuVentana, image=imagenlogo)
        self.label_imagenlogo.pack()

        Label(self.menuVentana, text=f"Buenas, {self.current_user.username}!", bg="#fde9fb", font=("arial", 16, "bold")).pack(pady=20)

        jugarBoton = Button(self.menuVentana, text="Jugar", bg="#ca61bf", fg="white", font=("arial", 12, 'bold'), width=15, command=self.start_quiz)
        jugarBoton.pack(pady=20)

        cerrarSesion = Button(self.menuVentana, text="Cerrar Sesión", bg="#ca61bf", fg="white", font=("arial", 12, 'bold'), width=15, command=self.cerrarSesion)
        cerrarSesion.pack(pady=20)

    def start_quiz(self):
        quizVentana = Toplevel()
        quizVentana.title("PAPI PREGUNTAS")
        quizVentana.geometry("1190x450")
        quizVentana.configure(bg='#fde9fb')
        quizVentana.resizable(False, False)

        quiz = Quiz(quizVentana, self.current_user)

    
    def cerrarSesion(self):
        self.menuVentana.destroy()


def start_quiz(user):
    quizVentana = Toplevel(ventana)
    quizVentana.title("PAPI PREGUNTAS")
    quizVentana.geometry("1190x450")
    quizVentana.configure(bg='#fde9fb')
    quizVentana.resizable(False, False)

    quiz = Quiz(quizVentana, user)

class Authentication:
    def __init__(self):
        self.users = []
        self.connection = sqlite3.connect("sqlite.db")
        self.cursor = self.connection.cursor()

    def registrarUser(self, username, password):
        self.cursor.execute("SELECT * FROM users WHERE username=?", (username,))
        existing_user = self.cursor.fetchone()

        if existing_user:
            mb.showerror("Error", "ya existe esa cuenta papi")
            return False
        else:
            self.cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            self.connection.commit()
            mb.showinfo("Registro exitoso", "estás papiregistradoo")
            return True

    def loginUser(self, username, password):
        self.cursor.execute("SELECT * FROM users WHERE username=?", (username,))
        user_data = self.cursor.fetchone()
        if user_data:
            if password == user_data[2]:
                mb.showinfo("Inicio de sesión exitoso", "¡Bienvenid@!")
                return User(username, password)
            else:
                mb.showerror("Error de inicio de sesión", "Contraseña incorrecta.")
        else:
            mb.showerror("Error de inicio de sesión", "No existis en la db amigo, registrate")
        return None

auth = Authentication()

ventana = Tk()
ventana.geometry("350x700")
ventana.title("Papi Preguntas")
ventana.configure(bg='#fde9fb')

def gato():
    papitext = Label(ventana, text="No jodas al papigato.", bg="#fde9fb", fg="#ca61bf", font=("arial", 10, 'bold'),  width=350)
    papitext.pack(pady=5)
    label_imagen.unbind("<Button-1>")


imagenlogo = PhotoImage(file=f"logo.png").subsample(2, 2)
label_imagenlogo = Label(ventana, image=imagenlogo)
label_imagenlogo.pack()

register_button = Button(ventana, text="Registrarse",  bg="#ca61bf", fg="white", font=("arial", 12, 'bold'), width=15, command=lambda: RegisterPag(ventana, auth))
register_button.pack()

login_button = Button(ventana, text="Iniciar sesión",  bg="#ca61bf", fg="white", font=("arial", 12, 'bold'),  width=15, command=lambda: LoginPag(ventana, auth))
login_button.pack(pady=25)


imagen = PhotoImage(file=f"elpapigato.png").subsample(1,1)
label_imagen = Label(ventana, image=imagen)
label_imagen.pack(pady=10)
label_imagen.bind("<Button-1>", lambda event: gato())

papitext = Label(ventana, text="El papigato te está juzgando.", bg="#fde9fb", fg="#ca61bf", font=("arial", 10, 'bold'),  width=350)
papitext.pack(pady=5)

ventana.mainloop()
