import sqlite3
from tkinter import *
from tkinter import messagebox as mb

class User:
    def __init__(self, username, password):
        self.username = username
        self.password = password

class Quiz:
    def __init__(self, master, current_user):
        self.master = master
        self.q_no = 0
        self.display_title()
        self.opt_selected = IntVar()
        self.opts = self.radio_buttons()
        self.buttons()
        self.correct = 0
        self.current_user = current_user

        self.connection = sqlite3.connect("sqlite.db")
        self.cursor = self.connection.cursor()

        self.cursor.execute("SELECT * FROM preguntas")
        self.questions_data = self.cursor.fetchall()
        self.data_size = len(self.questions_data)

        if self.data_size > 0:
            self.display_question()
            self.display_options()
        else:
            mb.showerror("Error", "No hay preguntas en la base de datos.")
            master.destroy()

    def display_result(self):
        wrong_count = self.data_size - self.correct
        correct = f"Correctas: {self.correct}"
        wrong = f"Erroneas (te falla): {wrong_count}"
        mb.showinfo("Papi resultados", f"\n{correct}\n{wrong}")
      #  if self.correct > 3 : 
      #  self.imagen = PhotoImage(file=f"happycat.png")
      #  self.label_imagen = Label(gui, image=imagen)
      #  self.label_imagen.pack()
        

    def check_ans(self, q_no):
        if self.opt_selected.get() == int(self.questions_data[q_no][5]):
            return True

    def next_btn(self):
        if self.check_ans(self.q_no):
            self.correct += 1

        self.q_no += 1

        if self.q_no == self.data_size:
            self.display_result()
            self.master.destroy()
        else:
            self.display_question()
            self.display_options()

    def buttons(self):
        next_button = Button(self.master, text="Siguiente papi pregunta", command=self.next_btn,
                             width=20, bg="blue", fg="white", font=("ariel", 16, "bold"))
        next_button.place(x=350, y=380)

        quit_button = Button(self.master, text="Salir", command=self.master.destroy,
                             width=5, bg="black", fg="white", font=("ariel", 16, " bold"))
        quit_button.place(x=700, y=50)

    def display_options(self):
        val = 0
        self.opt_selected.set(0)

        for option in range(1, 5): 
            if val < len(self.opts):
                self.opts[val]['text'] = self.questions_data[self.q_no][option]
                val += 1

    def display_question(self):
        q_no = Label(self.master, text=self.questions_data[self.q_no][0], width=60,
                     font=('ariel', 16, 'bold'), anchor='w')
        q_no.place(x=70, y=100)

    def display_title(self):
        title = Label(self.master, text="Papi Preguntas",
                      width=50, bg="pink", fg="white", font=("ariel", 20, "bold"))
        title.place(x=0, y=2)

    def radio_buttons(self):
        q_list = []
        y_pos = 150

        for _ in range(4):
            radio_btn = Radiobutton(self.master, text=" ", variable=self.opt_selected,
                                    value=len(q_list) + 1, font=("ariel", 14))
            q_list.append(radio_btn)
            radio_btn.place(x=100, y=y_pos)
            y_pos += 40

        return q_list

class RegistrationWindow:
    def __init__(self, master, auth_instance):
        self.master = master
        self.auth_instance = auth_instance
        self.create_registration_window()

    def create_registration_window(self):
        self.register_screen = Toplevel(self.master)
        self.register_screen.title("Registro")
        self.register_screen.geometry("400x300")

        Label(self.register_screen, text="Registro", font=("ariel", 16, "bold")).pack()

        self.username_label = Label(self.register_screen, text="Nombre de usuario:")
        self.username_label.pack()
        self.username_entry = Entry(self.register_screen)
        self.username_entry.pack()

        self.password_label = Label(self.register_screen, text="Contraseña:")
        self.password_label.pack()
        self.password_entry = Entry(self.register_screen, show="*")
        self.password_entry.pack()

        Button(self.register_screen, text="Registrarse", command=self.register_user).pack()

    def register_user(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        if self.auth_instance.register_user(username, password):
            self.register_screen.destroy()

class LoginWindow:
    def __init__(self, master, auth_instance):
        self.master = master
        self.auth_instance = auth_instance
        self.create_login_window()

    def create_login_window(self):
        self.login_screen = Toplevel(self.master)
        self.login_screen.title("Inicio de sesión")
        self.login_screen.geometry("400x300")

        Label(self.login_screen, text="Inicio de sesión", font=("ariel", 16, "bold")).pack()

        self.username_label = Label(self.login_screen, text="Nombre de usuario:")
        self.username_label.pack()
        self.username_entry = Entry(self.login_screen)
        self.username_entry.pack()

        self.password_label = Label(self.login_screen, text="Contraseña:")
        self.password_label.pack()
        self.password_entry = Entry(self.login_screen, show="*")
        self.password_entry.pack()

        Button(self.login_screen, text="Iniciar sesión", command=self.login_user).pack()

    def login_user(self):
        username = self.username_entry.get()
        password = self.password_entry.get()

        user = self.auth_instance.login_user(username, password)
        if user:
            self.login_screen.destroy()
            start_quiz(user)

def start_quiz(user):
    quiz_screen = Toplevel(gui)
    quiz_screen.title("PAPI PREGUNTAS")
    quiz_screen.geometry("800x450")

    quiz = Quiz(quiz_screen, user)

class Authentication:
    def __init__(self):
        self.users = []
        self.connection = sqlite3.connect("sqlite.db")
        self.cursor = self.connection.cursor()

    def register_user(self, username, password):
        self.cursor.execute("SELECT * FROM users WHERE username=?", (username,))
        existing_user = self.cursor.fetchone()

        if existing_user:
            mb.showerror("Error", "El usuario ya existe.")
            return False
        else:
            self.cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
            self.connection.commit()
            mb.showinfo("Registro exitoso", "¡Registro completado!")
            return True

    def login_user(self, username, password):
        self.cursor.execute("SELECT * FROM users WHERE username=?", (username,))
        user_data = self.cursor.fetchone()
        if user_data:
            if password == user_data[2]:
                mb.showinfo("Inicio de sesión exitoso", "¡Bienvenid@!")
                return User(username, password)
            else:
                mb.showerror("Error de inicio de sesión", "Contraseña incorrecta.")
        else:
            mb.showerror("Error de inicio de sesión", "Usuario no encontrado. Por favor, regístrate.")
        return None

auth = Authentication()

gui = Tk()
gui.geometry("400x300")
gui.title("Papi Preguntas")

register_button = Button(gui, text="Registrarse", command=lambda: RegistrationWindow(gui, auth))
register_button.pack(pady=20)

login_button = Button(gui, text="Iniciar sesión", command=lambda: LoginWindow(gui, auth))
login_button.pack(pady=20)

imagen = PhotoImage(file=f"elpapigato.png")
label_imagen = Label(gui, image=imagen)
label_imagen.pack()


gui.mainloop()
