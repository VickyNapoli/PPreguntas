import sqlite3
import tkinter as tk
from tkinter import messagebox

class JuegoPreguntas:
    def __init__(self, root, usuario):
        self.root = root
        self.usuario = usuario
        self.root.title(f"Juego de Preguntas y Respuestas - Usuario: {usuario}")
        self.conn = sqlite3.connect("database.db")
        self.c = self.conn.cursor()


        self.c.execute("SELECT COUNT(*) FROM preguntas")
        if self.c.fetchone()[0] == 0:
            self.insertar_preguntas_por_defecto()

        self.mostrar_pregunta()

        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)

    def insertar_preguntas_por_defecto(self):
        preguntas_por_defecto = [
            ("¿Cuál es la capital de Francia?", "París", "Londres", "Berlín", "Madrid"),
            ("¿En qué año se independizó Estados Unidos?", "1776", "1789", "1804", "1820"),
            ("¿Cuál es el río más largo del mundo?", "Amazonas", "Nilo", "Misisipi", "Yangtsé")
        ]

        for pregunta in preguntas_por_defecto:
            self.c.execute(
                """
                INSERT INTO preguntas (pregunta, respuesta_correcta, opcion_a, opcion_b, opcion_c)
                VALUES (?, ?, ?, ?, ?)
                """,
                pregunta
            )

        self.conn.commit()

    def mostrar_pregunta(self):
        self.c.execute("SELECT * FROM preguntas ORDER BY RANDOM() LIMIT 1")
        pregunta = self.c.fetchone()

        if pregunta:
            ventana_juego = tk.Toplevel(self.root)
            juego = Juego(self.conn, ventana_juego, pregunta, self.mostrar_pregunta)
        else:
            messagebox.showerror("Error", "No hay preguntas en la base de datos. Agrega preguntas para jugar.")

class Juego:
    def __init__(self, conn, root, pregunta, mostrar_pregunta):
        self.conn = conn
        self.root = root
        self.pregunta = pregunta
        self.mostrar_pregunta = mostrar_pregunta

        self.root.title("Juego: Pregunta y Respuestas")

        self.label_pregunta = tk.Label(root, text=pregunta[1])
        self.label_pregunta.pack(pady=10)

        respuestas = [pregunta[i] for i in range(2, 6)]
        respuestas_correctas = [pregunta[2]]

        self.boton_respuestas = []
        for i, respuesta in enumerate(respuestas):
            boton_respuesta = tk.Button(root, text=respuesta, command=lambda r=respuesta: self.verificar_respuesta(r))
            boton_respuesta.pack(pady=5)
            self.boton_respuestas.append(boton_respuesta)

    def verificar_respuesta(self, respuesta_usuario):
        respuesta_correcta = self.pregunta[2]
        if respuesta_usuario == respuesta_correcta:
            messagebox.showinfo("Correcto", "¡Respuesta correcta!")
        else:
            messagebox.showerror("Incorrecto", f"Respuesta incorrecta. La respuesta correcta es: {respuesta_correcta}")

        self.root.destroy()

        self.mostrar_pregunta()

def registrar_usuario(conn, username, password):
    cursor = conn.cursor()
    cursor.execute("INSERT INTO usuarios (username, password) VALUES (?, ?)", (username, password))
    conn.commit()

def iniciar_sesion(conn, username, password, root, entrada_usuario, entrada_contrasena, ventana_login):
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM usuarios WHERE username = ? AND password = ?", (username, password))
    usuario = cursor.fetchone()

    if usuario:
        messagebox.showinfo("Inicio de sesión exitoso", f"Bienvenido, {username}!")
        ventana_login.destroy()
        root.deiconify()
        entrada_usuario.delete(0, tk.END)
        entrada_contrasena.delete(0, tk.END)
        juego_preguntas = JuegoPreguntas(root, username)
    else:
        messagebox.showerror("Error de inicio de sesión", "Credenciales incorrectas")

def abrir_ventana_registro(conn, entrada_usuario, entrada_contrasena):
    ventana_registro = tk.Toplevel()
    ventana_registro.title("Registro")

    label_usuario = tk.Label(ventana_registro, text="Usuario:")
    label_contrasena = tk.Label(ventana_registro, text="Contraseña:")
    entrada_usuario_registro = tk.Entry(ventana_registro)
    entrada_contrasena_registro = tk.Entry(ventana_registro, show="*")
    boton_registro = tk.Button(ventana_registro, text="Registrarse", command=lambda: registrar_nuevo_usuario(conn, entrada_usuario_registro.get(), entrada_contrasena_registro.get(), ventana_registro))

    label_usuario.grid(row=0, column=0, sticky=tk.E)
    label_contrasena.grid(row=1, column=0, sticky=tk.E)
    entrada_usuario_registro.grid(row=0, column=1)
    entrada_contrasena_registro.grid(row=1, column=1)
    boton_registro.grid(row=2, column=1)

def registrar_nuevo_usuario(conn, username, password, ventana_registro):
    if username and password:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE username = ?", (username,))
        existente = cursor.fetchone()

        if not existente:
            registrar_usuario(conn, username, password)
            messagebox.showinfo("Registro exitoso", f"Usuario {username} registrado correctamente.")
            ventana_registro.destroy()
        else:
            messagebox.showerror("Error de registro", "El usuario ya existe.")
    else:
        messagebox.showerror("Error de registro", "Ingresa un usuario y una contraseña.")

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Inicio de Sesión")
    root.geometry("300x150")

    label_usuario = tk.Label(root, text="Usuario:")
    label_contrasena = tk.Label(root, text="Contraseña:")
    entrada_usuario = tk.Entry(root)
    entrada_contrasena = tk.Entry(root, show="*")
    boton_inicio_sesion = tk.Button(root, text="Iniciar Sesión", command=lambda: iniciar_sesion(juego_preguntas.conn, entrada_usuario.get(), entrada_contrasena.get(), root, entrada_usuario, entrada_contrasena, ventana_login))
    boton_registro = tk.Button(root, text="Registrarse", command=lambda: abrir_ventana_registro(juego_preguntas.conn, entrada_usuario, entrada_contrasena))

    label_usuario.grid(row=0, column=0, sticky=tk.E)
    label_contrasena.grid(row=1, column=0, sticky=tk.E)
    entrada_usuario.grid(row=0, column=1)
    entrada_contrasena.grid(row=1, column=1)
    boton_inicio_sesion.grid(row=2, column=1, pady=5)
    boton_registro.grid(row=3, column=1)

    ventana_login = tk.Toplevel(root)
    ventana_login.title("Login")
    ventana_login.withdraw()  # Oculta la ventana de login inicialmente

    juego_preguntas = JuegoPreguntas(ventana_login, "")

    root.mainloop()
